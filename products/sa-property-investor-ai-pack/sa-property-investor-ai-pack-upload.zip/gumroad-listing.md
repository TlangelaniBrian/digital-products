# The SA Property Investor AI Pack — Gumroad Listing

## Product name
The SA Property Investor AI Pack

## Subtitle
36 practical AI prompts for South African rental investors

## Short description
Copy-paste-ready ChatGPT and Claude prompts for analysing deals, stress-testing cash flow, screening tenants, handling maintenance, and making smarter property decisions in the South African market.

## Full description
South African property investing is not hard because the maths is impossible.

It is hard because the work gets messy.

You are comparing deals, checking yields, speaking to agents, chasing tenants, reviewing quotes, handling arrears, and trying not to make an expensive stupid decision.

**The SA Property Investor AI Pack** helps with that.

It gives you 36 sharp prompts designed for South African rental-property reality, not vague global real-estate fluff. Use them with ChatGPT or Claude to think faster, draft faster, and spot weak deals earlier.

Use it to:

- screen property deals quickly
- backsolve offer prices
- stress-test bond and vacancy risk
- draft tenant and arrears messages
- compare contractor quotes
- build maintenance and reserve plans
- decide whether to hold, sell, refinance, or walk away

## What’s inside

- 6 deal-screening prompts
- 6 finance and cash-flow prompts
- 6 due-diligence and negotiation prompts
- 6 tenant-operations prompts
- 6 maintenance and property-management prompts
- 6 portfolio and exit prompts

## Who it’s for

- buy-to-let investors
- first-time rental property buyers
- small landlords
- side-hustle property operators
- co-investors who need sharper reporting and decisions

## Who it’s not for

- people looking for legal advice disguised as prompts
- pure house flippers who do not manage rentals
- investors who want theory instead of practical operating help

## Why this is different

Most AI prompt packs are generic sludge.

This one is focused on a painful operating niche with real money on the line.

It is built around the decisions South African property investors actually make every week.

## Format

- digital handbook
- copy-paste-ready prompts
- works with ChatGPT and Claude
- plain-English instructions with placeholders

## Pricing

- Launch price: **R249**
- Regular price: **R399**

## Gumroad bullets

- Analyse SA property deals faster
- Draft sharper tenant and contractor messages
- Stress-test cash flow before you buy
- Useful for landlords, not just dreamers
- Built for South African rental reality

## Call to action

Buy it once, then use it every time a deal, tenant problem, or maintenance mess lands on your desk.
